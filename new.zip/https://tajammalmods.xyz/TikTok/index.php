<!DOCTYPE html>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tajammal Mods TikTok Free Views</title>

  <!--
    - favicon
  -->
  <link rel="shortcut icon" href="./assets/images/logo.ico" type="image/x-icon">

  <!--
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!--
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
</head>

<body>

  <!--
    - #MAIN
  -->

  <main>

    <!--
      - #SIDEBAR
    -->

    <aside class="sidebar" data-sidebar>

      <div class="sidebar-info">

        <figure class="avatar-box">
          <img src="./assets/images/my-avatar.png" alt="Richard hanrick" width="80">
        </figure>

        <div class="info-content">
          <h1 class="name" title="Richard hanrick">Tajammal Mods </h1>

          <p class="title">Digital Marketer</p>
        </div>

        <button class="info_more-btn" data-sidebar-btn>
          <span>Show Contacts</span>

          <ion-icon name="chevron-down"></ion-icon>
        </button>

      </div>

      <div class="sidebar-info_more">

        <div class="separator"></div>

        <ul class="contacts-list">

          <li class="contact-item">

            <div class="icon-box">
              <ion-icon name="mail-outline"></ion-icon>
            </div>

            <div class="contact-info">
              <p class="contact-title">Email</p>

              <a href="mailto:tajammalsmmpanel@gmail.com" class="contact-link">tajammalsmmpanel@gmail.com</a>
            </div>

          </li>

          <li class="contact-item">

            <div class="icon-box">
              <ion-icon name="phone-portrait-outline"></ion-icon>
            </div>

            <div class="contact-info">
              <p class="contact-title">Phone</p>

              <a href="tel:+447922640523" class="contact-link">+447922640523</a>
            </div>

          </li>

          <li class="contact-item">

            <div class="icon-box">
              <ion-icon name="time"></ion-icon>
            </div>

            <div class="contact-info">
              <p class="contact-title">Working Hours</p>

              <time datetime="1982-06-23">24 Hours</time>
            </div>

          </li>

          <li class="contact-item">

            <div class="icon-box">
              <ion-icon name="location-outline"></ion-icon>
            </div>

            <div class="contact-info">
              <p class="contact-title">Location</p>

              <address>Punjab Pakistan</address>
            </div>

          </li>

        </ul>

        <div class="separator"></div>

        <ul class="social-list">
            
                  <li class="social-item">
            <a href="https://www.instagram.com/tajammalmods" class="social-link">
              <ion-icon name="logo-instagram"></ion-icon>
            </a>
          </li>


          <li class="social-item">
            <a href="https://whatsapp.com/channel/0029VaVFGy5ISTkS0xRQNW0l" class="social-link">
              <ion-icon name="logo-whatsapp"></ion-icon>
            </a>
          </li>

          <li class="social-item">
            <a href="https://t.me/TajammalMods" class="social-link">
              <ion-icon name="logo-apple-appstore"></ion-icon>
            </a>
          </li>

    
        </ul>

      </div>

    </aside>



      <article class="about  active" data-page="about">

        <header>
          <h2 class="h2 article-title">Free TikTok Views By Tajammal</h2>
        </header>

       
       
            <li class="service-item">

              <div class="service-icon-box">
                <img src="./assets/images/icon-dev.svg" alt="Web development icon" width="40">
              </div>

              <div class="service-content-box">
                <h4 class="h4 service-item-title">TikTok Free Views</h4>
 <p class="blog-text">
                    Do Not Place Multiple Order At One Time </p>
            <form action='' method='get'>
                          <input type='text' name='link' class='form-input' placeholder='PAST LINK' required>
                          <br><br>
                          <input type='submit' class='form-btn' name='submit' value='submit'>              </div>

            </li>


  <!--
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!--
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  
  
        <div class="separator"></div>

        <ul class="social-list">
            
                  <li class="social-item">
            <a href="https://www.instagram.com/tajammalmods" class="social-link">
              <ion-icon name="logo-instagram"></ion-icon>
            </a>
          </li>

<br><br><br>
          <li class="social-item">
            <a href="https://whatsapp.com/channel/0029VaVFGy5ISTkS0xRQNW0l" class="social-link">
              <ion-icon name="logo-whatsapp"></ion-icon>
            </a>
          </li>
<br><br><br>
          <li class="social-item">
            <a href="https://t.me/TajammalMods" class="social-link">
              <ion-icon name="logo-apple-appstore"></ion-icon>
            </a>
          </li>

    <br><br><br>
        </ul>

      </div>

    </aside>

</body>

</html>